EFUZYLIC ; efuzy local licensing and activation helpers
 ;
 Q
 ;
CFG(CONF) ; normalize licensing defaults into CONF
 N MODE
 S MODE=$$MODE($G(CONF("efuzy","license","mode")))
 S CONF("efuzy","license","mode")=MODE
 I $G(CONF("efuzy","license","edition"))="" S CONF("efuzy","license","edition")=$$EDITION("",MODE)
 I $G(CONF("efuzy","license","filePath"))="" S CONF("efuzy","license","filePath")="instance/license/efuzy.license"
 I $G(CONF("efuzy","license","installIdPath"))="" S CONF("efuzy","license","installIdPath")="instance/license/efuzy.install_id"
 S CONF("efuzy","license","hostStrategy")=$$HOSTSTGY($G(CONF("efuzy","license","hostStrategy")))
 I $G(CONF("efuzy","license","product"))="" S CONF("efuzy","license","product")="efuzy"
 I $G(CONF("efuzy","license","requireValidOnStartup"))="" S CONF("efuzy","license","requireValidOnStartup")=$S(MODE="demo":0,1:1)
 Q
 ;
CHECK(CONF,RES) ; alias for STATUS
 I $Q Q $$STATUS(.CONF,.RES)
 D STATUS(.CONF,.RES)
 Q
 ;
STATUS(CONF,RES) ; inspect effective activation state
 N OK,MODE,LIC,ERR,IDRES,TODAY,EXP,MAINT,LICED,HOST,HOSTCFG,INSTALLID,REQID
 K RES
 D CFG(.CONF)
 S MODE=$$MODE($G(CONF("efuzy","license","mode")))
 S OK=1
 S TODAY=$$TODAY()
 S RES("routine")="EFUZYLIC"
 S RES("mode")=MODE
 S RES("edition")=$$EDITION($G(CONF("efuzy","license","edition")),MODE)
 S RES("product")=$G(CONF("efuzy","license","product"),"efuzy")
 S RES("licensePath")=$$LICPATH(.CONF)
 S RES("installIdPath")=$$IDPATH(.CONF)
 S RES("hostStrategy")=$$HOSTSTGY($G(CONF("efuzy","license","hostStrategy")))
 S RES("today")=TODAY
 D READID(.CONF,.IDRES)
 M RES("install")=IDRES
 I MODE="demo" D  Q:$Q 1 Q
 . S RES("ok")=1
 . S RES("status")="demo"
 . S RES("licensed")=0
 . S RES("demo")=1
 . D STAMP(.RES)
 I $G(RES("licensePath"))="" D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="license_path_missing"
 . D STAMP(.RES)
 I '$$FEX($G(RES("licensePath"))) D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="missing"
 . S RES("error")="license_file_missing"
 . D STAMP(.RES)
 I '$$LOAD($G(RES("licensePath")),.LIC,.ERR) D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")=$G(ERR("error"),"license_read_failed")
 . D STAMP(.RES)
 M RES("license")=LIC
 I $$LC($G(LIC("product")))'="efuzy" D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="license_product_mismatch"
 . D STAMP(.RES)
 S LICED=$$LC($G(LIC("edition")))
 I MODE="evaluation",LICED'="evaluation" D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="license_edition_invalid"
 . D STAMP(.RES)
 I MODE="paid",'$$ISPAIDED(LICED) D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="license_edition_invalid"
 . D STAMP(.RES)
 S EXP=$$DATE10($G(LIC("expires_at")))
 I MODE="evaluation",EXP="" D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="evaluation_expiry_required"
 . D STAMP(.RES)
 I EXP'="",$$DATENUM(EXP)<$$DATENUM(TODAY) D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="expired"
 . S RES("error")="license_expired"
 . D STAMP(.RES)
 S MAINT=$$DATE10($G(LIC("maintenance_until")))
 S RES("supportActive")=$S(MAINT="":1,$$DATENUM(MAINT)<$$DATENUM(TODAY):0,1:1)
 I 'RES("supportActive") S RES("warning")="maintenance_expired"
 S INSTALLID=$G(IDRES("installId"))
 S REQID=$G(LIC("install_id"))
 I REQID'="",INSTALLID'=REQID D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="install_id_mismatch"
 . D STAMP(.RES)
 S HOST=$$HOSTID(.CONF)
 S HOSTCFG=$$LC($G(LIC("host")))
 I $G(RES("hostStrategy"))'="none",HOSTCFG'="",HOSTCFG'="any",HOSTCFG'=$$LC(HOST) D  Q:$Q 0 Q
 . S RES("ok")=0
 . S RES("status")="invalid"
 . S RES("error")="license_host_mismatch"
 . D STAMP(.RES)
 S RES("ok")=OK
 S RES("licensed")=1
 S RES("demo")=0
 S RES("status")=$S(MODE="evaluation":"evaluation",1:"licensed")
 D STAMP(.RES)
 Q:$Q OK Q
 ;
ENSUREID(CONF,RES) ; create local install id if missing
 N PATH,ID,ERR,DIR
 K RES
 D CFG(.CONF)
 S PATH=$$IDPATH(.CONF)
 S RES("routine")="EFUZYLIC"
 S RES("installIdPath")=PATH
 I PATH="" S RES("ok")=0,RES("error")="install_id_path_missing" Q:$Q 0 Q
 S DIR=$$DIRNAME(PATH)
 I DIR'="",'$$ENSDIR(DIR,.ERR) S RES("ok")=0,RES("error")=$G(ERR("error"),"install_id_dir_failed") Q:$Q 0 Q
 I $$FEX(PATH) D  Q:$Q +$G(RES("ok")) Q
 . I '$$READ1(PATH,.ID) S RES("ok")=0,RES("error")="install_id_read_failed" Q
 . S ID=$$TRIM(ID)
 . I ID="" S RES("ok")=0,RES("error")="install_id_empty" Q
 . S RES("ok")=1
 . S RES("installId")=ID
 . S RES("status")="existing"
 S ID=$$NEWID()
 I '$$WRITE1(PATH,ID) S RES("ok")=0,RES("error")="install_id_write_failed" Q:$Q 0 Q
 S RES("ok")=1
 S RES("installId")=ID
 S RES("status")="created"
 Q:$Q 1 Q
 ;
READID(CONF,RES) ; read install id without creating state
 N PATH,ID
 K RES
 D CFG(.CONF)
 S PATH=$$IDPATH(.CONF)
 S RES("routine")="EFUZYLIC"
 S RES("installIdPath")=PATH
 I PATH="" S RES("ok")=0,RES("error")="install_id_path_missing" Q:$Q 0 Q
 I '$$FEX(PATH) S RES("ok")=0,RES("status")="missing",RES("error")="install_id_missing" Q:$Q 0 Q
 I '$$READ1(PATH,.ID) S RES("ok")=0,RES("error")="install_id_read_failed" Q:$Q 0 Q
 S ID=$$TRIM(ID)
 I ID="" S RES("ok")=0,RES("error")="install_id_empty" Q:$Q 0 Q
 S RES("ok")=1
 S RES("installId")=ID
 S RES("status")="present"
 Q:$Q 1 Q
 ;
LOAD(PATH,LIC,ERR) ; load simple key=value license file
 N DEV,OLDIO,DONE,LINE,KEY,VAL,FOUND
 K LIC,ERR
 S DEV=$G(PATH),OLDIO=$IO,DONE=0,FOUND=0
 O DEV:(READONLY:STREAM):1 E  S ERR("error")="license_open_failed" Q:$Q 0 Q
 U DEV
 F  Q:DONE  D
 . D READROW(.LINE,.DONE,.ERR)
 . I DONE Q
 . I $D(ERR) Q
 . S LINE=$$TRIM($G(LINE))
 . I LINE="" Q
 . I $E(LINE)="#" Q
 . I $E(LINE)=";" Q
 . D PARSEKV(LINE,.KEY,.VAL)
 . I KEY="" Q
 . S FOUND=1
 . S LIC(KEY)=VAL
 C DEV U OLDIO
 I $D(ERR) Q:$Q 0 Q
 I 'FOUND S ERR("error")="license_empty" Q:$Q 0 Q
 S LIC("product")=$S($G(LIC("product"))'="":$G(LIC("product")),1:"efuzy")
 Q:$Q 1 Q
 ;
PARSEKV(LINE,KEY,VAL)
 N P
 S KEY="",VAL=""
 S P=$F($G(LINE),"=")
 I P'>1 Q
 S KEY=$$LC($$TRIM($E(LINE,1,P-2)))
 S VAL=$$TRIM($E(LINE,P,$L(LINE)))
 Q
 ;
READROW(LINE,DONE,ERR)
 N $ETRAP,$ESTACK
 S LINE=""
 S $ETRAP="D RDERR^EFUZYLIC"
 R LINE:1
 S $ETRAP=""
 I '$T D  Q
 . I $ZEOF S DONE=1 Q
 . S ERR("error")="license_read_timeout"
 I $ZEOF,LINE="" S DONE=1 Q
 I $E(LINE,$L(LINE))=$C(13) S LINE=$E(LINE,1,$L(LINE)-1)
 Q
 ;
RDERR
 I $ZSTATUS["IOEOF" S DONE=1,$ECODE="" Q
 S ERR("error")="license_read_failed",$ECODE="" Q
 ;
STAMP(RES)
 K ^MIO("EFUZY","license","last")
 M ^MIO("EFUZY","license","last")=RES
 S ^MIO("EFUZY","license","last","checkedAt")=$$NOWISO^MIOUTIL()
 Q
 ;
LICPATH(CONF)
 D CFG(.CONF)
 Q $$NORMPATH($G(CONF("efuzy","license","filePath")))
 ;
IDPATH(CONF)
 D CFG(.CONF)
 Q $$NORMPATH($G(CONF("efuzy","license","installIdPath")))
 ;
MODE(X)
 N M
 S M=$$LC($G(X))
 I M="evaluation" Q M
 I M="paid" Q M
 Q "demo"
 ;
EDITION(X,MODE)
 N E,M
 S E=$$LC($G(X)),M=$$MODE($G(MODE))
 I E'="" Q E
 I M="evaluation" Q "evaluation"
 I M="paid" Q "standard"
 Q "demo"
 ;
HOSTSTGY(X)
 N H
 S H=$$LC($G(X))
 I H="name" Q H
 I H="hostname" Q "name"
 Q "none"
 ;
HOSTID(CONF)
 N H
 S H=$G(CONF("efuzy","license","hostId"))
 I H="" S H=$ZTRNLNM("EFUZY_HOST_ID")
 I H="" S H=$ZTRNLNM("HOSTNAME")
 I H="" S H="unknown"
 Q H
 ;
ISPAIDED(X)
 N E
 S E=$$LC($G(X))
 Q $S(E="standard":1,E="professional":1,E="enterprise":1,E="source":1,E="source_license":1,1:0)
 ;
TODAY()
 Q $E($$NOWISO^MIOUTIL(),1,10)
 ;
DATE10(X)
 N D
 S D=$E($G(X),1,10)
 I D?4N1"-"2N1"-"2N Q D
 Q ""
 ;
NEWID()
 N ID
 S ID=$$UUID^MIOUTIL()
 I ID="" S ID="efuzy-"_$J_"-"_$TR($$NOWISO^MIOUTIL(),"-:TZ","")
 Q ID
 ;
READ1(PATH,OUT)
 N DEV,LINE
 S OUT="",DEV=$G(PATH)
 O DEV:(READONLY:STREAM):1 E  Q 0
 U DEV
 R LINE:1
 C DEV
 S OUT=$G(LINE)
 I $E(OUT,$L(OUT))=$C(13) S OUT=$E(OUT,1,$L(OUT)-1)
 Q 1
 ;
WRITE1(PATH,TXT)
 N DEV
 S DEV=$G(PATH)
 O DEV:(NEWVERSION:STREAM:NOWRAP:WRITEONLY):1 E  Q 0
 U DEV W $G(TXT),!
 C DEV
 Q 1
 ;
ENSDIR(PATH,ERR)
 N CMD,PROBE
 K ERR
 I $G(PATH)="" Q 1
 S CMD="mkdir -p '"_$TR($G(PATH),"'","''")_"'"
 ZSY CMD
 S PROBE=$G(PATH)_"/.efuzy_lic_probe"
 O PROBE:(NEWVERSION:STREAM:NOWRAP:WRITEONLY):1 E  D  Q 0
 . S ERR("error")="license_dir_probe_failed"
 U PROBE W "ok" C PROBE
 ZSY "rm -f '"_$TR(PROBE,"'","''")_"'"
 Q 1
 ;
FEX(PATH)
 N DEV
 S DEV=$G(PATH)
 I DEV="" Q 0
 O DEV:(readonly:stream:nowrap):1 E  Q 0
 C DEV
 Q 1
 ;
DATENUM(X)
 N D
 S D=$$DATE10($G(X))
 I D="" Q 0
 Q +$TR(D,"-","")
 ;
DIRNAME(PATH)
 N I,P
 S P=$$NORMPATH($G(PATH))
 F I=$L(P):-1:1 I $E(P,I)="/" Q
 I I<1 Q ""
 Q $E(P,1,I-1)
 ;
NORMPATH(PATH)
 N P
 S P=$G(PATH)
 I $E(P,1,2)="./" S P=$E(P,3,$L(P))
 F  Q:$E(P,$L(P))'="/"  S P=$E(P,1,$L(P)-1) Q:P=""
 Q P
 ;
TRIM(X)
 Q $$TRIM^MIOUTIL($G(X))
 ;
LC(X)
 Q $ZCONVERT($G(X),"L")
 ;
