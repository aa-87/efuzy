EFUZYLICT ; tests for EFUZYLIC
 ;
 Q
 ;
START
 D T001
 D T002
 D T003
 D T004
 D T005
 Q
 ;
T001 ; demo mode remains license-free
 N ROOT,CONF,RES
 S ROOT=$$TMPROOT^EFUZYTESTU("lic1")
 D RESET^EFUZYTESTU(ROOT)
 D SETCONF^EFUZYTESTU(.CONF,ROOT)
 S CONF("efuzy","license","mode")="demo"
 D EQ^MIOTASSERT($$STATUS^EFUZYLIC(.CONF,.RES),1,"[T001][demo ok]")
 D EQ^MIOTASSERT($G(RES("status")),"demo","[T001][status]")
 D RESET^EFUZYTESTU(ROOT)
 Q
 ;
T002 ; paid mode requires a license file
 N ROOT,CONF,RES
 S ROOT=$$TMPROOT^EFUZYTESTU("lic2")
 D RESET^EFUZYTESTU(ROOT)
 D SETCONF^EFUZYTESTU(.CONF,ROOT)
 S CONF("efuzy","license","mode")="paid"
 S CONF("efuzy","license","filePath")=ROOT_"/license/efuzy.license"
 S CONF("efuzy","license","installIdPath")=ROOT_"/license/efuzy.install_id"
 D EQ^MIOTASSERT($$STATUS^EFUZYLIC(.CONF,.RES),0,"[T002][paid fail]")
 D EQ^MIOTASSERT($G(RES("error")),"license_file_missing","[T002][error]")
 D RESET^EFUZYTESTU(ROOT)
 Q
 ;
T003 ; paid mode passes with matching install id
 N ROOT,CONF,RES,LFILE,IDFILE,ID,OK
 S ROOT=$$TMPROOT^EFUZYTESTU("lic3")
 D RESET^EFUZYTESTU(ROOT)
 D SETCONF^EFUZYTESTU(.CONF,ROOT)
 S CONF("efuzy","license","mode")="paid"
 S LFILE=ROOT_"/license/efuzy.license"
 S IDFILE=ROOT_"/license/efuzy.install_id"
 D MKDIR^EFUZYTESTU(ROOT_"/license")
 S ID="lic3-install"
 D WRITEFILE^EFUZYTESTU(IDFILE,ID,.OK)
 D WRLIC^EFUZYTESTU(LFILE,"professional",ID,"",$$DATEPLUS^EFUZYTESTU(30),.OK)
 S CONF("efuzy","license","filePath")=LFILE
 S CONF("efuzy","license","installIdPath")=IDFILE
 D OK^MIOTASSERT($$STATUS^EFUZYLIC(.CONF,.RES),"[T003][paid ok]")
 D EQ^MIOTASSERT($G(RES("status")),"licensed","[T003][status]")
 D EQ^MIOTASSERT($G(RES("licensed")),1,"[T003][licensed]")
 D RESET^EFUZYTESTU(ROOT)
 Q
 ;
T004 ; evaluation licenses expire cleanly
 N ROOT,CONF,RES,LFILE,IDFILE,ID,OK
 S ROOT=$$TMPROOT^EFUZYTESTU("lic4")
 D RESET^EFUZYTESTU(ROOT)
 D SETCONF^EFUZYTESTU(.CONF,ROOT)
 S CONF("efuzy","license","mode")="evaluation"
 S LFILE=ROOT_"/license/efuzy.license"
 S IDFILE=ROOT_"/license/efuzy.install_id"
 D MKDIR^EFUZYTESTU(ROOT_"/license")
 S ID="lic4-install"
 D WRITEFILE^EFUZYTESTU(IDFILE,ID,.OK)
 D WRLIC^EFUZYTESTU(LFILE,"evaluation",ID,"",$$DATEPLUS^EFUZYTESTU(-1),.OK)
 S CONF("efuzy","license","filePath")=LFILE
 S CONF("efuzy","license","installIdPath")=IDFILE
 D EQ^MIOTASSERT($$STATUS^EFUZYLIC(.CONF,.RES),0,"[T004][evaluation fail]")
 D EQ^MIOTASSERT($G(RES("error")),"license_expired","[T004][error]")
 D RESET^EFUZYTESTU(ROOT)
 Q
 ;
T005 ; host-bound licenses can be enforced when configured
 N ROOT,CONF,RES,LFILE,IDFILE,ID,OK
 S ROOT=$$TMPROOT^EFUZYTESTU("lic5")
 D RESET^EFUZYTESTU(ROOT)
 D SETCONF^EFUZYTESTU(.CONF,ROOT)
 S CONF("efuzy","license","mode")="paid"
 S CONF("efuzy","license","hostStrategy")="name"
 S CONF("efuzy","license","hostId")="host-a"
 S LFILE=ROOT_"/license/efuzy.license"
 S IDFILE=ROOT_"/license/efuzy.install_id"
 D MKDIR^EFUZYTESTU(ROOT_"/license")
 S ID="lic5-install"
 D WRITEFILE^EFUZYTESTU(IDFILE,ID,.OK)
 D WRLIC^EFUZYTESTU(LFILE,"enterprise",ID,"host-b",$$DATEPLUS^EFUZYTESTU(30),.OK)
 S CONF("efuzy","license","filePath")=LFILE
 S CONF("efuzy","license","installIdPath")=IDFILE
 D EQ^MIOTASSERT($$STATUS^EFUZYLIC(.CONF,.RES),0,"[T005][host fail]")
 D EQ^MIOTASSERT($G(RES("error")),"license_host_mismatch","[T005][error]")
 D RESET^EFUZYTESTU(ROOT)
 Q
 ;
